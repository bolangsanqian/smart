package com.shuanghong.smart.domain.req;

import com.shuanghong.smart.domain.info.DataSyncInfo;
import lombok.Data;

@Data
public class DataSyncRequest extends DataSyncInfo {


}
