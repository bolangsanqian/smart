package com.shuanghong.smart.domain.info;

/**
 * 温度对象
 * @Description
 * @Author
 * @Date 2020-07-07 19:33
 */
public class TemperatureInfo extends IndicatorInfo {

}
