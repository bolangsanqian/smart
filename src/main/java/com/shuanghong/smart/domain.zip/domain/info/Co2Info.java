package com.shuanghong.smart.domain.info;

/**
 * CO2 对象
 * @Description
 * @Author
 * @Date 2020-07-07 19:33
 */
public class Co2Info extends IndicatorInfo {
}
